package edu.niagara.cis258.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity4 extends AppCompatActivity {


    String[] GoalList = new String[10];
    EditText etInput;
    String temp="";
    int count=0;
    TextView tvDispList;

    List<String> myGoalList = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        etInput = (EditText)findViewById(R.id.etInput);
        tvDispList = (TextView)findViewById(R.id.tvDispList);
    }

    public void goAdd(View v){
        temp = etInput.getText().toString();
        if (count<10) {
            GoalList[count] = temp;
            count = count + 1;
        } else {

        }

        myGoalList.add(temp); // ArrayList


        displayListElement();

    }
    public void displayListElement(){
        temp=""+myGoalList.size()+": ";
        for(int i=0; i<myGoalList.size(); i++){
            temp = temp + myGoalList.get(i)+",";
        }
        tvDispList.setText(temp);
    }
    public void goBack(View v){
        startActivity(new Intent(MainActivity4.this,MainActivity3.class));

    }

}
