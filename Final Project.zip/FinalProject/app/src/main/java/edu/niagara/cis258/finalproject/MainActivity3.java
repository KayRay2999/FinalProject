package edu.niagara.cis258.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void goGoal(View v) {
        startActivity(new Intent(MainActivity3.this, MainActivity4.class));
    }
    public void goHealth(View v) {
        startActivity(new Intent(MainActivity3.this, MainActivity5.class));
    }
    public void goHelp(View v) {
        startActivity(new Intent(MainActivity3.this, MainActivity4.class));
    }
    public void goSpot(View v) {
        startActivity(new Intent(MainActivity3.this, MainActivity4.class));
    }
    public void goCheck(View v) {
        startActivity(new Intent(MainActivity3.this, MainActivity4.class));
    }

}